#!/bin/bash

uptime
